
/**
 * Write a description of class BillPlease here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class Billplease
{
    public static void main (String args[])
    {    new Billplease ();
    }
    
    public Billplease()
    {
        System.out.println ("**************************");
        System.out.println ("WELCOME TO VIDHI'S DINER!!");
        System.out.println ("**************************");
        
        double tab = IBIO.inputDouble ("\nWhat is the dinner tab? ");
        
        double tax = tab*0.13;
        
        double tipPercent = IBIO.inputInt ("What is the tip percent? ");
        
        double tip = tab * (tipPercent/100);
        
        double totalbill = tax + tip + tab;
        
        System.out.println ("Your total is: $"+totalbill);
        
        int diners = IBIO.inputInt ("\nHow many diners? ");
        
        double share = totalbill/diners;
        
        System.out.println ("Each diner's share: $"+share);
        System.out.println ("\nHave an amazing day!");
        
    }
}    